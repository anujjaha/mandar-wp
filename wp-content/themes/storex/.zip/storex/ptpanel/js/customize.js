jQuery(document).ready(function($) { 
	$("select, input[type=checkbox], input[type=radio], input[type=file]").styler(); 
	//$("input,select,textarea,radio").not("[type=submit]").jqBootstrapValidation();
});
