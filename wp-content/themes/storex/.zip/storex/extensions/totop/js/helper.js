jQuery(document).ready(function($) {
	'use strict';

	$().UItoTop({ easingType: 'easeOutQuart' });
});